-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 31, 2019 at 02:23 PM
-- Server version: 10.1.38-MariaDB
-- PHP Version: 7.3.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `gamingbuddy`
--

-- --------------------------------------------------------

--
-- Table structure for table `gb_account`
--

CREATE TABLE `gb_account` (
  `ID` int(11) NOT NULL,
  `Username` varchar(30) NOT NULL,
  `Password` varchar(255) NOT NULL,
  `Name` varchar(30) NOT NULL,
  `LastName` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `gb_account`
--

INSERT INTO `gb_account` (`ID`, `Username`, `Password`, `Name`, `LastName`) VALUES
(1, 'woco', '$2y$10$xrcTnJJT7SOacsqUU1PIFu0hdYCqKcZyJCSjqycROIsar2frsoX8O', 'Wouter', 'Cornelis'),
(2, 'matth', '$2y$10$xrcTnJJT7SOacsqUU1PIFu0hdYCqKcZyJCSjqycROIsar2frsoX8O', 'Matthias', 'Hernalsteen'),
(3, 'petsel', '$2y$10$rGgHDmPKucSLM95rtek3iuaiQnkj28ht5ag483ISVCyz6HXp36EjK', 'Peter', 'Selie'),
(4, 'lolplayer', '$2y$10$QgWykm.4YZKkcXVfUDPfveEKJSfWvDI.XZbbHrreLWXGadTI65Rvu', 'League', 'Player'),
(21, 'kookpot', '$2y$10$s7hEXDT7pTlObpmA1U27jehp/fc9u1b1Uz06.WtcYIsLVE9LyLikO', 'Pot', 'Kook'),
(22, 'wachtwoordtest', '$2y$10$57faHUbF8diYfBQoMe9Nf.xFUBh5YXW.u.blqSsC2aEV6gWuYEvAi', 'lol', 'lol'),
(24, 'qwerty', '$2y$10$1NjXo6rykiEytmoRRuBAVuSSE0nu6HUSs1q0GoMeuNEnSNnVXwrO2', 'qwerty', 'okokokok'),
(38, 'aanmaaktest', '$2y$10$6IXO71gphNo1QvY1X1llFeK2I.zAt9h8qImYr1bvdwp.H1ULNyj9K', 'Test', '123'),
(39, 'een', '$2y$10$LZkai/4e9dRjv7BRBnxjsujAGivz7j.jVYZMrXJ/EEOZJPalCV1Vq', 'Dit', 'is'),
(40, 'test60', '$2y$10$gg8mOHKwxGQg4MPRG7zOxuunhq38EdcZNMM/hHyNUrkhVCxiZCRLi', 'dit', 'is');

-- --------------------------------------------------------

--
-- Table structure for table `gb_game`
--

CREATE TABLE `gb_game` (
  `ID` int(11) NOT NULL,
  `Name` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `gb_game`
--

INSERT INTO `gb_game` (`ID`, `Name`) VALUES
(1, 'League of Legends'),
(2, 'Counterstrike: Global Offensive');

-- --------------------------------------------------------

--
-- Table structure for table `gb_loldata`
--

CREATE TABLE `gb_loldata` (
  `LoLID` int(11) NOT NULL,
  `AccountID` int(11) NOT NULL,
  `GameID` int(11) NOT NULL DEFAULT '1',
  `SummonerName` varchar(40) NOT NULL,
  `RankID` int(11) NOT NULL,
  `PrefRole1` int(11) NOT NULL,
  `PrefRole2` int(11) NOT NULL,
  `Zone` varchar(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `gb_loldata`
--

INSERT INTO `gb_loldata` (`LoLID`, `AccountID`, `GameID`, `SummonerName`, `RankID`, `PrefRole1`, `PrefRole2`, `Zone`) VALUES
(1, 1, 1, 'Woco', 9, 3, 5, 'EUW'),
(2, 2, 1, 'SummonerMatthias', 11, 4, 5, 'EUW'),
(3, 4, 1, 'EenNaam', 22, 2, 6, 'NA'),
(4, 3, 1, 'test', 27, 5, 2, 'NA'),
(57, 2, 1, 'aanmaaktest2', 27, 1, 2, 'LAN'),
(58, 38, 1, 'Aanmaaktest', 27, 1, 6, 'EUW'),
(60, 40, 1, 'lol', 11, 3, 6, 'EUW');

-- --------------------------------------------------------

--
-- Table structure for table `gb_lolrank`
--

CREATE TABLE `gb_lolrank` (
  `rankID` int(11) NOT NULL,
  `Name` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `gb_lolrank`
--

INSERT INTO `gb_lolrank` (`rankID`, `Name`) VALUES
(1, 'Iron IV'),
(2, 'Iron III'),
(3, 'Iron II'),
(4, 'Iron I'),
(5, 'Bronze IV'),
(6, 'Bronze III'),
(7, 'Bronze II'),
(8, 'Bronze I'),
(9, 'Silver IV'),
(10, 'Silver III'),
(11, 'Silver II'),
(12, 'Silver I'),
(13, 'Gold IV'),
(14, 'Gold III'),
(15, 'Gold II'),
(16, 'Gold I'),
(17, 'Platinum IV'),
(18, 'Platinum III'),
(19, 'Platinum II'),
(20, 'Platinum I'),
(21, 'Diamond IV'),
(22, 'Diamond III'),
(23, 'Diamond II'),
(24, 'Diamond I'),
(25, 'Master'),
(26, 'Grand Master'),
(27, 'Challenger');

-- --------------------------------------------------------

--
-- Table structure for table `gb_lolrole`
--

CREATE TABLE `gb_lolrole` (
  `roleID` int(11) NOT NULL,
  `Name` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `gb_lolrole`
--

INSERT INTO `gb_lolrole` (`roleID`, `Name`) VALUES
(1, 'Top'),
(2, 'Jungler'),
(3, 'Mid'),
(4, 'Bot'),
(5, 'Support'),
(6, 'Fill');

-- --------------------------------------------------------

--
-- Table structure for table `gb_lolzone`
--

CREATE TABLE `gb_lolzone` (
  `zoneID` varchar(4) NOT NULL,
  `Name` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `gb_lolzone`
--

INSERT INTO `gb_lolzone` (`zoneID`, `Name`) VALUES
('BR', 'Brazil'),
('CN', 'People\'s Republic of China'),
('EUNE', 'Europe Nordic & East'),
('EUW', 'Europe West'),
('JP', 'Japan'),
('KR', 'Republic of Korea'),
('LAN', 'Latin America North'),
('LAS', 'Latin America South'),
('NA', 'North America'),
('OCE', 'Oceania'),
('RU', 'Russia'),
('SEA', 'South East Asia'),
('TR', 'Turkey');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `gb_account`
--
ALTER TABLE `gb_account`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `gb_game`
--
ALTER TABLE `gb_game`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `gb_loldata`
--
ALTER TABLE `gb_loldata`
  ADD PRIMARY KEY (`LoLID`),
  ADD KEY `Zone` (`Zone`),
  ADD KEY `PrefRole1` (`PrefRole1`),
  ADD KEY `PrefRole2` (`PrefRole2`),
  ADD KEY `RankID` (`RankID`),
  ADD KEY `GameID` (`GameID`),
  ADD KEY `gb_loldata_ibfk_7` (`AccountID`);

--
-- Indexes for table `gb_lolrank`
--
ALTER TABLE `gb_lolrank`
  ADD PRIMARY KEY (`rankID`);

--
-- Indexes for table `gb_lolrole`
--
ALTER TABLE `gb_lolrole`
  ADD PRIMARY KEY (`roleID`);

--
-- Indexes for table `gb_lolzone`
--
ALTER TABLE `gb_lolzone`
  ADD PRIMARY KEY (`zoneID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `gb_account`
--
ALTER TABLE `gb_account`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;

--
-- AUTO_INCREMENT for table `gb_game`
--
ALTER TABLE `gb_game`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `gb_loldata`
--
ALTER TABLE `gb_loldata`
  MODIFY `LoLID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=61;

--
-- AUTO_INCREMENT for table `gb_lolrank`
--
ALTER TABLE `gb_lolrank`
  MODIFY `rankID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT for table `gb_lolrole`
--
ALTER TABLE `gb_lolrole`
  MODIFY `roleID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `gb_loldata`
--
ALTER TABLE `gb_loldata`
  ADD CONSTRAINT `gb_loldata_ibfk_1` FOREIGN KEY (`Zone`) REFERENCES `gb_lolzone` (`zoneID`),
  ADD CONSTRAINT `gb_loldata_ibfk_2` FOREIGN KEY (`PrefRole1`) REFERENCES `gb_lolrole` (`roleID`),
  ADD CONSTRAINT `gb_loldata_ibfk_3` FOREIGN KEY (`PrefRole2`) REFERENCES `gb_lolrole` (`roleID`),
  ADD CONSTRAINT `gb_loldata_ibfk_4` FOREIGN KEY (`RankID`) REFERENCES `gb_lolrank` (`rankID`),
  ADD CONSTRAINT `gb_loldata_ibfk_6` FOREIGN KEY (`GameID`) REFERENCES `gb_game` (`ID`),
  ADD CONSTRAINT `gb_loldata_ibfk_7` FOREIGN KEY (`AccountID`) REFERENCES `gb_account` (`ID`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
